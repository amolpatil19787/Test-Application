<?php
// This file was auto-generated from sdk-root/src/data/appstream/2016-12-01/paginators-1.json
return [ 'pagination' => [ 'DescribeImagePermissions' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], 'DescribeImages' => [ 'input_token' => 'NextToken', 'output_token' => 'NextToken', 'limit_key' => 'MaxResults', ], ],];
